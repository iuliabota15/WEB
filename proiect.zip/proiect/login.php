<?php
header('Content-type: text/html; charset=utf-8');

$host = "localhost";
$user = "root";
$password = "";
$database = "hotel";

$conn = new mysqli($host, $user, $password, $database);
if (!$conn) {
    die("Conexiunea a eșuat: " . mysqli_connect_error());
}
  
session_start();
$email = $_POST['email'];
$parola = $_POST['parola'];

if (empty($email) || empty($parola)) {
    $errorMessage = "Introduceți adresa de email și parola.";
} else {
    $stmt = $conn->prepare("SELECT * FROM Utilizator WHERE email=? AND parola=?");
    $stmt->bind_param("ss", $email, $parola);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $_SESSION["email"] = $email;
        $_SESSION["logged_in"] = true;
    
        // Obțineți numele și prenumele utilizatorului din baza de date
        $stmt = $conn->prepare("SELECT nume, prenume FROM Utilizator WHERE email=?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
    
        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            $nume = $row["nume"];
            $prenume = $row["prenume"];
    
            // Stocați numele și prenumele în sesiune
            $_SESSION["nume"] = $nume;
            $_SESSION["prenume"] = $prenume;

            echo $_SESSION['nume']; // verifică dacă afișează corect numele utilizatorului
            echo $_SESSION['prenume']; // verifică dacă afișează corect prenumele utilizatorului

            // Verificați adresa de email a utilizatorului admin
            if ($email == "hotelcaelya@gmail.com") {
                header("Location: rez.php");
                exit();
            } else {
                header("Location: text.php");
                exit();
            }
        }
    } else {
        $errorMessage = "Adresa de email sau parola este greșită.";
    }
}

mysqli_close($conn);

if (!empty($errorMessage)) {
    echo $errorMessage;
}
?>
