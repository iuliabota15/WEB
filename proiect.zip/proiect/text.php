
<!DOCTYPE html>
<html lang="en">
<head>
    
    <title>HomePage</title>
    <link href="text.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <meta charset="utf-8">

<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/00ae1fa8ee.js" crossorigin="anonymous"></script>

</head>
<body>

  <!---------navar-->
<section class="header">
      <nav>
        <a href="text.php"><img src="img/logo.png"></a>
        <div class="nav-links" id="navLinks">
          <i class="fa fa-times" onclick="hideMenu()"></i>
          <ul>
            <li><a href="rezervare_clienti.php" > REZERVĂ</a></li>
            <li><a href="text.php"  id="login-link-home"> HOME</a></li>
            <li><a href="restaurant.php"  id="rest-link"> RESTAURANT</a></li>
            <li><a href="camere.php"  id="camere-link"> CAMERE</a></li>
            <li><a href="spa.html"  id="spa-link"> BEAUTY & SPA</a></li>
            <li><a href="contact.html"  id="contact-link" > CONTACT</a></li>
            
            <li><a href="login.html"  id="login-link"> LOGIN</a></li>
            
            <li><a href="edit_profile.html"  id="login-link-edit"> EDITARE CONT</a></li>
            <style>
              .logout-form {
                display: inline;
              }
            </style>
            <form id="logout-form" class="logout-form" action="logout.php" method="post">
              <li><a href="#" onclick="logout()">LOGOUT</a></li>
            </form>
            <p  style="color: white; text-align: right; margin-right: 18px; "   id="salut">
              <?php
              session_start();

              // Verifică dacă cheile 'nume' și 'prenume' există în $_SESSION
              if (isset($_SESSION['nume']) && isset($_SESSION['prenume'])) {
                  echo "Bine ai venit , " . $_SESSION['nume'] . " " . $_SESSION['prenume'] .  "!";
              }
              ?>
            </p>

            </ul>
  
        </div>
        <i class="fa fa-bars" onclick="showMenu()"></i>
      </nav>
  
  
      <div class="text-box">
        <h1>Încântarea<br>simțurilor</h1>
        <p>Oază de rafinament și eleganță în inima orașului.</p>
        <a href="camere.php" class="hero-btn">Detalii</a>
      </div> 
</section>
    <!------------course------>

<section class="course">
  <div class="row">
    <div class="slide-right">
      <h1 style="color: #777; font-size: 35px;">Experiență rafinată în inima Ardealului.</h1>
      <p>Experimentează priveliștea unică, rafinatul gust al preparatelor Fine Dining și confortul desăvârșit al camerelor ce oferă căldura unui Boutique Hotel. Iar pentru ca experiența să fie completă, răsfață-te alegând dintre serviciile noastre de 4****.</p>
      <p></p>
      <a href="contact.html">
        <button  class="gradient-btn-btn">AFLĂ MAI MULTE</button>
      </a>
      
      <p></p>
       </div>
    <div class="course-col">
      <img src="img/info.png" />
          
    </div>
    
  </div>
</section>
 
<!----changing photos-->

<section class="image-container">
  <div class="text-overlays">
    <p style="color: white; font-size: 35px;">FINE DINING</p>
    <p style="color: white;font-size: 25px;">Restaurant</p>
    <a href="restaurant.php" class="hero-btn">Detalii</a>

  </div>
  <!---<img src="img/img.jpg" alt="Image 1" id="image1" style="width: 50%;">-->
  <div class="cf-container">
    <img class="bottom" src="img/img.jpg" />
    <img class="top" src="img/cpy.jpg" />
  </div>
  <div class="text-overlayd">
    <p style="color: white; font-size: 35px;">CU ȘI FĂRĂ TERASĂ</p>
    <p style="color: white; font-size: 25px;">Camere</p>
    <a href="camere.php" class="hero-btn">Detalii</a>
  </div>

  <!--<img src="img/img4.jpg" alt="Image 1" id="image2" style="float: right; width: 50%;">-->
  <div class="cf-container">
    <img class="bottom" src="img/cpy3.jpg" />
    <img class="top" src="img/novum.jpg" />
  </div>
</section>

<!--info_final-->

<section class="course">
  <div class="row">
    <div class="slide-right">
      <h1 style="color: #777; font-size: 35px;">Servicii de 4****</h1>
      <p></p>
      <p>BOUTIQUE HOTEL & RESTAURANT</p>
      <p></p>
      <p>Vă oferim servicii remarcabile pentru a ne asigura că ați avut o ședere minunată și o experiență de 4****.</p>
      <p></p>
      <p></p>
      <a href="spa.html">

        
      <button class="gradient-btn-btn">AFLĂ MAI MULTE</button>
      </a>
      <p></p>
       </div>
    
  </div>
</section>
<section class="course2">
  <img src="img/logo.png"/>
  <div class="row2">
    <div class="course-col2">
      <h3 style="color: #777; font-size: 25px;">Rezervari</h3>
      <p>(+40) 723 534 558   |   (+40) 786 713 722</p>
      <p>rezervari@caelya.com</p>

    </div>

    <div class="course-col2">
      <h3 style="color: #777; font-size: 25px;">Adresa</h3>
      <p>Strada Bumbacului nr.16</p>
      <p>415600 Oradea, Romania</p>

    </div>


  </div>
</section>

<section class="course3">
  <h3 style="color: #838383; font-size: 20px;">Urmărește-ne</h3>
  <div class="row3">
    <a href="https://www.instagram.com/katyperry/" target="_blank"><button class="fa-brands fa-instagram" style="color: #838383;"></button></a>
    <a href="https://www.facebook.com/ellentv/" target="_blank"><button class="fa-brands fa-facebook" style="color: #838383;"></button></a>
    <a href="https://www.youtube.com/channel/UCNL1ZadSjHpjm4q9j2sVtOA" target="_blank"><button class="fa-brands fa-youtube"  style="color: #838383;"></button></a>
  </div>
</section>


<section class="course4" style="color: #777;">
  <p style="color: #222; font-size: small; padding-top: 5px;padding-bottom: 5px; text-align: center;">Copyright ©2008-2020 Hotel Cataleya. Toate drepturile rezervate.</p>
</section>

  <script>
    var navLinks=document.getElementById("navLinks");
    function showMenu(){
      navLinks.style.right="0";
    }
    function hideMenu(){
      navLinks.style.right="-200px";
    }

    





    // Set the images and texts in arrays
const images = ['restaurant.jpg', 'bar.jpg', 'fine_dining.jpg'];
const texts = ['Încântarea simțurilor', 'Descoperă experiențe unice', 'Bucură-te de rafinamentul culinar'];
const ps=['Oază de rafinament și eleganță în inima orașului.','Explorăm împreună noi orizonturi.','Descoperă arta gastronomiei și încântă-ți simțurile!']
// Set the starting index
let index = 0;

// Get the image and text elements
const imageElement = document.querySelector('.header');
const textElement = document.querySelector('.text-box h1');
const psElement = document.querySelector('.text-box p');

// Function to change the image and text
function changeImageAndText() {
  // Increment the index
  index++;

  // If index is out of bounds, reset it to 0
  if (index >= images.length) {
    index = 0;
  }

  // Set the new image and text
  imageElement.style.backgroundImage = `linear-gradient( rgb(0,0,0,0.7),rgb(0,0,0,0.7)),url(img/${images[index]})`;
  textElement.textContent = texts[index];
  psElement.textContent = ps[index];
}

// Call the function every 5 seconds
setInterval(changeImageAndText, 5000);

  </script>
<script>
  function logout() {
  var xhr = new XMLHttpRequest();
  xhr.open("POST", "logout.php", true);
  xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4 && xhr.status === 200) {
      window.location.href = "login.html";
    }
  };
  xhr.send();
}</script>
  
</body>
</html>