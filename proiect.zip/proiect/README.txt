//1
text.html - HomePage ul Site ului meu
text.css

Această pagină web prezintă un hotel de lux și facilitățile sale. Structura paginii este împărțită în mai multe secțiuni:

Meniul - aceasta conține un logo al hotelului și un meniu de navigare care permite utilizatorilor să acceseze diferitele secțiuni ale paginii web, inclusiv Rezervare, Acasă, Restaurant, Camere, Beauty & Spa, Contact și Login.Fiecare buton te trimite la pagina aferenta a siteului meu web.Pentru telefonul mobil acest meniu va disparea si va aparea la apasarea iconitei de meniu.Meniul de navigare permite utilizatorilor să acceseze rapid secțiunile web dorite.
!!MENIUL RAMANE PENTRU TOATE PAGINILE DIN PROIECTUL MEU!!

Schimbarea Fotografiilor- Am facut u carusel automatic de poze care se deruleaza automat dupa o perioada de timp.Atat pozele cat si textul lor se schimba.Apasand butonul "Detalii" vei fi trimis catre pagina legata de camerele hotelului.

Info - această secțiune include o imagine de fundal și un text de prezentare a hotelului.Textul vine de la stanga la dreapta.

Poze&Detalii - această secțiune prezintă câteva dintre serviciile de top ale hotelului și invită utilizatorii să afle mai multe despre ele. Cand punem cursorul pe imagini acestea se schimba cu alte imagini. Apasand butonul "Detalii" de la fiecare poza, acesta ne va trimite in pagina pentru Restaurant,respectiv Camere.

Info_final - această secțiune conține mai multe informații despre serviciile oferite de hotel și invită utilizatorii să afle mai multe despre Beauty & Spa.(Apasand butonul "Afla mai multe"). Textul vine din stanga spre dreapta.

La finalul paginii, avem informatii legate de Rezervari si Adresahotelului , alaturi de logo-ul nostru. De asemenea avem si niste iconite cu scopul de a informa oamenii ca ne pot contacte pe retelele de socializare.




//2
login.html -Logarea 
login.css

Această pagină web este o pagină de autentificare pentru utilizatori care doresc să faca o rezervare. Aceasta are o bara de navigare sus care include un logo& meniul. 

În mijlocul paginii se află o cutie cu câmpuri de introducere a informațiilor de conectare, cum ar fi adresa de e-mail și parola. 

De asemenea, există un buton de conectare  pentru a trimite informațiile de autentificare la server. Sub acest buton există o opțiune pentru a păstra utilizatorii autentificați ("Ține-mă minte") și un link pentru a restabili parola. Există, de asemenea, un link către pagina de înregistrare, pentru utilizatorii care nu au încă un cont pe site. (register.html)

În partea de jos a paginii există un cod JavaScript care controlează comportamentul meniului. Funcțiile "showMenu()" și "hideMenu()" sunt utilizate pentru a face meniul să apară și să dispară în momentul în care utilizatorul face clic pe iconitele hamburger menu sau x(exit).




//3
register.html -Inregistrarea
register.css

Această pagină web reprezintă un formular de înregistrare pentru utilizatorii care doresc să se înregistreze pe site-ul Caelya. Aspectul general al paginii este simplu și modern, fiind compus dintr-un meniu de navigare, un antet și un formular de înregistrare.

Meniul de navigare este situat în partea de sus a paginii și este format dintr-un logo și mai multe link-uri care redirecționează utilizatorul către alte pagini ale site-ului. Butonul din stânga logo-ului este un buton de tip burger care deschide meniul de navigare în cazul în care acesta este ascuns, iar cel din dreapta logo-ului este un buton de închidere a meniului.

Formularul de înregistrare conține următoarele câmpuri de completat:

Nume: un câmp text pentru introducerea numelui utilizatorului
Prenume: un câmp text pentru introducerea prenumelui utilizatorului
Adresa de email: un câmp text pentru introducerea adresei de email a utilizatorului
Parolă: un câmp pentru introducerea parolei utilizatorului
Confirmare parolă: un câmp pentru reintroducerea parolei utilizatorului în vederea confirmării acesteia
În partea de jos a formularului, există un buton de submit pentru a trimite datele introduse, precum și un checkbox pentru a accepta termenii și condițiile site-ului. În cazul în care utilizatorul a mai avut cont pe site, se poate conecta apăsând pe link-ul "Ai deja cont? Conectează-te aici.", care te duce la pagina de conectare (login.html)




//4
camere.html
camere.css

Aceasta este o pagină web pentru un hotel, cu mai multe secțiuni care prezintă diferitele sale facilități și camere disponibile.

În partea de sus a paginii, există un logo și un buton pentru a deschide și închide bara de navigație. 

Pe pagina principală există o secțiune care promovează apartamentele și camerele disponibile în hotel, cu o imagine a unei camere, o scurtă descriere și butonul pentru detalii.(care te trimite la pagina aferenta fiecarei camere).

Fiecare cameră are o secțiune dedicată cu o imagine, o descriere mai detaliată și butonul pentru a rezerva. Există, de asemenea, o secțiune pentru restaurant și o secțiune pentru facilități de frumusețe și spa. În partea de jos a paginii există butoane pentru a vizita paginile de social media ale hotelului.

Site-ul folosește culori pastelate și un font elegant pentru a comunica atmosfera rafinată a hotelului. Layout-ul este structurat și simplu de utilizat pentru a ajuta utilizatorii să acceseze rapid informațiile de care au nevoie.


//5
camera_junior.html
camera_junior.css

Pagina web are o imagine de fundal și un logo în partea de sus a paginii. Când derulați în jos, veți vedea un carusel cu imagini ale camerei, urmat de o secțiune cu specificații ale camerei, precum și o secțiune cu facilitățile disponibile. Aspectul general al paginii web pare să fie curat și modern, cu font-uri frumoase și utilizarea de icoane pentru a ajuta la identificarea fiecărei specificații și facilități.

De asemenea avem regulile hotelului si o mica descriere a camerei.

//6 camera_senior.html
//7 camera_famili.html
//8 camere_dubla.html     !!ACEEASI POVESTE CA LA CAMERA_JUNIOR, DAR DETALII DIFERITE !!!



//9 
spa.html
spa.css


Această pagină web este destinată promovării unui hotel spa și a serviciilor sale de frumusețe și relaxare. Pagina web are o structură simplă și este alcătuită din mai multe secțiuni care prezintă detalii despre serviciile de care pot beneficia clienții.


Următoarea secțiune prezintă o imagine și un titlu care descriu secțiunea de "BEAUTY & SPA" a hotelului.

În secțiunea următoare, este prezentată o descriere generală a hotelului și a serviciilor sale. Textul începe prin a explica conceptul de frumusețe și armonie spirituală din spatele hotelului și apoi descrie două spații diferite ale hotelului: salonul de înfrumusețare Tulip Beauty și centrul spa dedicat ritualurilor de relaxare - Tulip Spa Rituals.

Următoarea secțiune prezintă o fotografie a unei bazine cu hidromasaj (Jacuzzi) și detalii despre acesta, cum ar fi prețul și numărul de persoane care pot beneficia de serviciu.

Ultima secțiune se concentrează asupra centrului de înfrumusețare Tulip Beauty, descriind serviciile pe care le oferă, cum ar fi coafura, manichiura și tratamente de îngrijire a tenului.


//10
contact.html
contact.css

Slide-ul de prezentare: Slide-ul de prezentare este o imagine de fundal care este afișată pe pagina de start a site-ului. Acesta prezintă imaginea hărții cu locația hotelului.

Informații de contact: Această secțiune furnizează informații de contact pentru hotel. Aceasta include numerele de telefon și adresa.

Social media: Instagram, Facebook și YouTube.


//11

restaurant.html
restaurant.css

Pagina conține o secțiune de prezentare a restaurantului, cu trei imagini care sunt afișate într-un slideshow și butoane de navigare pentru a schimba imaginile afișate. 

Mai jos, sunt prezentate două butoane pliabile care pot fi deschise pentru a afișa mai multe detalii despre meniul restaurantului.



//12
rez.html
rez.css


Aceasta este o pagină web care este de fapt, un panou de control pentru administrarea unui hotel.

Pagina web are două secțiuni principale. Prima secțiune este antetul paginii, care conține bara de navigație și un banner cu textul "ADMINISTRARE HOTEL". Bara de navigație este interactivă și permite utilizatorului să navigheze prin paginile site-ului.

A doua secțiune este corpul paginii, care conține două cutii de vânzări, "Vânzări recente" și "Top Vânzări", care conțin informații despre vânzările recente și cele mai vândute camere ale hotelului. Acest lucru poate fi util pentru a monitoriza performanța și popularitatea hotelului



Important: Nu am facut inca pagina destinata rezervarii camerelor de  catre clienti, de aceea la apasarea butonului rezervari se afiseaza aceasta pagina. Aceasta pagina va fi vizibila doar adminului. Deci utilizatorul va avea alta pagina prin care va putea face o rezervare.!!!