<!DOCTYPE html>
<html lang="en">
<head>
    <title>Proiect Web</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="style.css">
    <link href="rez.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/00ae1fa8ee.js" crossorigin="anonymous"></script>

</head>
<body>

  <!---------navar-->
<section class="header">
      <nav>
        <a href="text.php"><img src="img/logo.png"></a>
        <div class="nav-links" id="navLinks">
          <i class="fa fa-times" onclick="hideMenu()"></i>
          <ul>
            <li><a href="rez.php" > REZERVĂ</a></li>
            <li><a href="login.html"  id="login-link"> LOGIN</a></li>
            <style>
              .logout-form {
                display: inline;
              }
            </style>
            <form id="logout-form" class="logout-form" action="logout.php" method="post">
              <li><a href="#" onclick="logout()">LOGOUT</a></li>
            </form>
          </ul>
  
        </div>
        <i class="fa fa-bars" onclick="showMenu()"></i>
      </nav>
  
  
      <div class="slide-right2">
        <div class="slide-right2-heading">
          <h1>ADMINISTRARE HOTEL</h1>
        </div>
    
      </div>
      
</section>

  <section class="home-section">
    
    <div class="home-content">
    
      <div class="sales-boxes">
        <div class="recent-sales box">
          
        <?php
// Conecțiunea la baza de date
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hotel";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verifică dacă există erori la conectare
if ($conn->connect_error) {
    die("Conectare eșuată: " . $conn->connect_error);
}

// Interogarea pentru a obține ultimele trei rezervări
$query = "SELECT check_in, check_out, email, pret, tip_camera FROM rezervare ORDER BY check_in DESC LIMIT 3";
$result = $conn->query($query);

// Construirea secțiunii HTML
$html = '<div class="title">Rezervări recente</div>' . "\n";
$html .= '<div class="sales-details">' . "\n";

// Adăugarea detaliilor rezervărilor
$html .= '<ul class="details">' . "\n";
$html .= '<li class="topic">In</li>' . "\n";

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $checkInDate = date("d M Y", strtotime($row["check_in"]));
        $html .= '<li>' . $checkInDate . '</li>' . "\n";
    }
}

$html .= '</ul>' . "\n";
$html .= '<ul class="details">' . "\n";
$html .= '<li class="topic">Out</li>' . "\n";

if ($result->num_rows > 0) {
    $result->data_seek(0); // Resetează pointerul rezultatului
    while ($row = $result->fetch_assoc()) {
        $checkOutDate = date("d M Y", strtotime($row["check_out"]));
        $html .= '<li>' . $checkOutDate . '</li>' . "\n";
    }
}

$html .= '</ul>' . "\n";
$html .= '<ul class="details">' . "\n";
$html .= '<li class="topic">Email</li>' . "\n";

if ($result->num_rows > 0) {
    $result->data_seek(0); // Resetează pointerul rezultatului
    while ($row = $result->fetch_assoc()) {
        $html .= '<li>' . $row["email"] . '</li>' . "\n";
    }
}

$html .= '</ul>' . "\n";
$html .= '<ul class="details">' . "\n";


$html .= '</ul>' . "\n";
$html .= '<ul class="details">' . "\n";
$html .= '<li class="topic">Tip cameră</li>' . "\n";

if ($result->num_rows > 0) {
    $result->data_seek(0); // Resetează pointerul rezultatului
    while ($row = $result->fetch_assoc()) {
       

        $html .= '<li>' . $row["tip"] . '</li>' . "\n";
    }
}

$html .= '</ul>' . "\n";
$html .= '<ul class="details">' . "\n";
$html .= '<li class="topic">Total de plată</li>' . "\n";

if ($result->num_rows > 0) {
    $result->data_seek(0); // Resetează pointerul rezultatului
    while ($row = $result->fetch_assoc()) {
        $html .= '<li>' . $row["pret"] . ' lei</li>' . "\n";
    }
}

$html .= '</ul>' . "\n";
$html .= '</div>' . "\n";

// Eliberarea rezultatului interogării și închiderea conexiunii
$result->free_result();
$conn->close();

// Afișarea secțiunii HTML
echo $html;
?>



</div>

        <div class="top-sales box">
          <div class="title">Top Vânzări</div>
          <ul class="top-sales-details">
            
          
          
          <li>
           
              <span class="product">Camere duble</span>
          
            <span class="price">544</span>
          </li>
          <li>
           
              <span class="product">Camere Family</span>
           
            <span class="price">343</span>
          </li>
          <li>
           
              <span class="product">Camere Junior</span>
            
            <span class="price">233</span>
          
          </ul>
        </div>
      
    </div>
  </section>





  <script>
    var navLinks=document.getElementById("navLinks");
    function showMenu(){
      navLinks.style.right="0";
    }
    function hideMenu(){
      navLinks.style.right="-200px";
    }
  </script>
  <script>
  function logout() {
  var xhr = new XMLHttpRequest();
  xhr.open("POST", "logout.php", true);
  xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4 && xhr.status === 200) {
      window.location.href = "login.html";
    }
  };
  xhr.send();
}</script>
</body>
</html>