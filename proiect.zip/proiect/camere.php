<?php
// Replace the values inside the brackets with your own database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hotel";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Camere</title>
    <link rel="stylesheet" href="style.css">
    <link href="camere.css" rel="stylesheet">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/00ae1fa8ee.js" crossorigin="anonymous"></script>

</head>
<body>

  <!---------navar-->
<section class="header">
      <nav>
        <a href="text.php"><img src="img/logo.png"></a>
        <div class="nav-links" id="navLinks">
          <i class="fa fa-times" onclick="hideMenu()"></i>
          <ul>
            <li><a href="rezervare_clienti.php" > REZERVĂ</a></li>
            <li><a href="text.php"  id="login-link-home"> HOME</a></li>
            <li><a href="restaurant.php"  id="rest-link"> RESTAURANT</a></li>
            <li><a href="camere.php"  id="camere-link"> CAMERE</a></li>
            <li><a href="spa.html"  id="spa-link"> BEAUTY & SPA</a></li>
            <li><a href="contact.html"  id="contact-link" > CONTACT</a></li>
            
            <li><a href="login.html"  id="login-link"> LOGIN</a></li>
            
            <li><a href="edit_profile.html"  id="login-link-edit"> EDITARE CONT</a></li>
            <style>
              .logout-form {
                display: inline;
              }
            </style>
            <form id="logout-form" class="logout-form" action="logout.php" method="post">
              <li><a href="#" onclick="logout()">LOGOUT</a></li>
            </form>
            

            </ul>
  
        </div>
        <i class="fa fa-bars" onclick="showMenu()"></i>
      </nav>
  
  
      <div class="slide-right2">
        <div class="slide-right2-heading">
          <h1>APARTAMENTE ȘI CAMERE</h1>
        </div>
        <div class="teext">
            <p>Oază de liniște si relaxare.</p>
          </div>
        <div class="slide-right2-button">
          <a href="rezervare_clienti.php" class="hero-btn">REZERVA ACUM</a>
        </div>
      </div>
      
</section>
    <!------------course------>
<?php
$sql = "SELECT * FROM camera WHERE denumire = 'Junior Suite'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $denumire = $row["denumire"];
        $descriere = $row["descriere"];
        $persoane = $row["persoane"];
        $dimensiune = $row["dimensiune"];
        $paturi = $row["paturi"];
        $tv = $row["tv"];
        $internet = $row["internet"];
        $aer_conditionat = $row["aer_conditionat"];
        $cale_imagine = $row["cale_imagine"];
        $minibar = $row["minibar"];
        $articole_toaleta = $row["articole_toaleta"];
        $descriere2 = $row["descriere2"];
    }
} else {
    echo "0 results";
}
?>

<section class="course">
  <div class="row">
    <div class="slide-right">
    <h1 style="color: #777; font-size: 35px;"><?php echo $denumire; ?></h1>
      <p></p>
      <p><?php echo $descriere; ?></p>
      <div class="row3">
        <div class="icon-container">
          <i class="fas fa-users" style="color: #777; font-size: 25px;"></i>
          <p><?php echo $persoane; ?></p>
        </div>
        <div class="icon-container">
          <i class="fas fa-compass" style="color: #777; font-size: 25px;"></i>
          <p><?php echo $dimensiune; ?></p>
        </div>
        <div class="icon-container">
          <i class="fas fa-bed" style="color: #777; font-size: 25px;"></i>
          <p><?php echo $paturi; ?></p>
        </div>
        <div class="icon-container">
          <i class="fas fa-tv" style="color: #777; font-size: 25px;"></i>
          <p><?php echo $tv; ?></p>
        </div>
        <div class="icon-container">
          <i class="fas fa-wifi" style="color: #777; font-size: 25px;"></i>
          <p><?php echo $internet; ?></p>
        </div>
        <div class="icon-container">
          <i class="fas fa-snowflake" style="color: #777; font-size: 25px;"></i>
          <p><?php echo $aer_conditionat; ?></p>
        </div>
      </div>
      <a href="camera_junior.php">
        <button class="gradient-btn-btn">DETALII</button>
      </a>
      
      <p></p>
      </div>
    <div class="course-col">
      <img src=<?php echo $cale_imagine; ?> />
          
    </div>
    
  </div>
</section>


<?php
$sql = "SELECT * FROM camera WHERE denumire = 'Sky Senior Suite'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $denumire = $row["denumire"];
        $descriere = $row["descriere"];
        $persoane = $row["persoane"];
        $dimensiune = $row["dimensiune"];
        $paturi = $row["paturi"];
        $tv = $row["tv"];
        $internet = $row["internet"];
        $aer_conditionat = $row["aer_conditionat"];
        $cale_imagine = $row["cale_imagine"];
        $minibar = $row["minibar"];
        $articole_toaleta = $row["articole_toaleta"];
        $descriere2 = $row["descriere2"];
    }
} else {
    echo "0 results";
}
?>

<section class="course">
    <div class="row">

        <div class="course-col">
        <img src=<?php echo $cale_imagine; ?> />
                
          </div>



      <div class="slide-right">
      <h1 style="color: #777; font-size: 35px;"><?php echo $denumire; ?></h1>
      <p></p>
      <p><?php echo $descriere; ?></p>
      <div class="row3">
        <div class="icon-container">
          <i class="fas fa-users" style="color: #777; font-size: 25px;"></i>
          <p><?php echo $persoane; ?></p>
        </div>
        <div class="icon-container">
          <i class="fas fa-compass" style="color: #777; font-size: 25px;"></i>
          <p><?php echo $dimensiune; ?></p>
        </div>
        <div class="icon-container">
          <i class="fas fa-bed" style="color: #777; font-size: 25px;"></i>
          <p><?php echo $paturi; ?></p>
        </div>
        <div class="icon-container">
          <i class="fas fa-tv" style="color: #777; font-size: 25px;"></i>
          <p><?php echo $tv; ?></p>
        </div>
        <div class="icon-container">
          <i class="fas fa-wifi" style="color: #777; font-size: 25px;"></i>
          <p><?php echo $internet; ?></p>
        </div>
        <div class="icon-container">
          <i class="fas fa-snowflake" style="color: #777; font-size: 25px;"></i>
          <p><?php echo $aer_conditionat; ?></p>
        </div>
      </div>
      <a href="camere_senior.php">
        <button class="gradient-btn-btn">DETALII</button>
      </a>
      
      <p></p>
      </div>
      
      
    </div>
  </section>
 
  <?php
$sql = "SELECT * FROM camera WHERE denumire = 'Camere duble'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $denumire = $row["denumire"];
        $descriere = $row["descriere"];
        $persoane = $row["persoane"];
        $dimensiune = $row["dimensiune"];
        $paturi = $row["paturi"];
        $tv = $row["tv"];
        $internet = $row["internet"];
        $aer_conditionat = $row["aer_conditionat"];
        $cale_imagine = $row["cale_imagine"];
        $minibar = $row["minibar"];
        $articole_toaleta = $row["articole_toaleta"];
        $descriere2 = $row["descriere2"];
    }
} else {
    echo "0 results";
}
?>
  <section class="course">
    <div class="row">
      <div class="slide-right">
      <h1 style="color: #777; font-size: 35px;"><?php echo $denumire; ?></h1>
      <p></p>
      <p><?php echo $descriere; ?></p>
      <div class="row3">
        <div class="icon-container">
          <i class="fas fa-users" style="color: #777; font-size: 25px;"></i>
          <p><?php echo $persoane; ?></p>
        </div>
        <div class="icon-container">
          <i class="fas fa-compass" style="color: #777; font-size: 25px;"></i>
          <p><?php echo $dimensiune; ?></p>
        </div>
        <div class="icon-container">
          <i class="fas fa-bed" style="color: #777; font-size: 25px;"></i>
          <p><?php echo $paturi; ?></p>
        </div>
        <div class="icon-container">
          <i class="fas fa-tv" style="color: #777; font-size: 25px;"></i>
          <p><?php echo $tv; ?></p>
        </div>
        <div class="icon-container">
          <i class="fas fa-wifi" style="color: #777; font-size: 25px;"></i>
          <p><?php echo $internet; ?></p>
        </div>
        <div class="icon-container">
          <i class="fas fa-snowflake" style="color: #777; font-size: 25px;"></i>
          <p><?php echo $aer_conditionat; ?></p>
        </div>
      </div>
      <a href="camera_dubla.php">
        <button class="gradient-btn-btn">DETALII</button>
      </a>
      
      <p></p>
      </div>
      <div class="course-col">
      <img src=<?php echo $cale_imagine; ?> />
            
      </div>
      
    </div>
  </section>


  <?php
$sql = "SELECT * FROM camera WHERE denumire = 'Camere Family'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $denumire = $row["denumire"];
        $descriere = $row["descriere"];
        $persoane = $row["persoane"];
        $dimensiune = $row["dimensiune"];
        $paturi = $row["paturi"];
        $tv = $row["tv"];
        $internet = $row["internet"];
        $aer_conditionat = $row["aer_conditionat"];
        $cale_imagine = $row["cale_imagine"];
        $minibar = $row["minibar"];
        $articole_toaleta = $row["articole_toaleta"];
        $descriere2 = $row["descriere2"];
    }
} else {
    echo "0 results";
}
?>
  <section class="course">
    <div class="row">

        <div class="course-col">
        <img src=<?php echo $cale_imagine; ?> />
                
          </div>



      <div class="slide-right">
      <h1 style="color: #777; font-size: 35px;"><?php echo $denumire; ?></h1>
      <p></p>
      <p><?php echo $descriere; ?></p>
      <div class="row3">
        <div class="icon-container">
          <i class="fas fa-users" style="color: #777; font-size: 25px;"></i>
          <p><?php echo $persoane; ?></p>
        </div>
        <div class="icon-container">
          <i class="fas fa-compass" style="color: #777; font-size: 25px;"></i>
          <p><?php echo $dimensiune; ?></p>
        </div>
        <div class="icon-container">
          <i class="fas fa-bed" style="color: #777; font-size: 25px;"></i>
          <p><?php echo $paturi; ?></p>
        </div>
        <div class="icon-container">
          <i class="fas fa-tv" style="color: #777; font-size: 25px;"></i>
          <p><?php echo $tv; ?></p>
        </div>
        <div class="icon-container">
          <i class="fas fa-wifi" style="color: #777; font-size: 25px;"></i>
          <p><?php echo $internet; ?></p>
        </div>
        <div class="icon-container">
          <i class="fas fa-snowflake" style="color: #777; font-size: 25px;"></i>
          <p><?php echo $aer_conditionat; ?></p>
        </div>
      </div>
      <a href="camera_family.php">
        <button class="gradient-btn-btn">DETALII</button>
      </a>
      
      <p></p>
      </div>
         </div>
      
      
    </div>
  </section>
  


  <script>
    var navLinks=document.getElementById("navLinks");
    function showMenu(){
      navLinks.style.right="0";
    }
    function hideMenu(){
      navLinks.style.right="-200px";
    }
  </script>
  <script>
  function logout() {
  var xhr = new XMLHttpRequest();
  xhr.open("POST", "logout.php", true);
  xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4 && xhr.status === 200) {
      window.location.href = "login.html";
    }
  };
  xhr.send();
}</script>
</body>
</html>