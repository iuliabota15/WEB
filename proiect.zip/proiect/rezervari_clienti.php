<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hotel";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexiunea la baza de date a eșuat: " . $conn->connect_error);
}

// Obțineți valorile selectate din formular
$checkin = $_POST['checkin'];
$checkout = $_POST['checkout'];
$micDejun = isset($_POST['mic_dejun']);
$faraMicDejun = isset($_POST['fara_mic_dejun']);

$micDejunS = isset($_POST['mic_dejun_s']);
$faraMicDejunS = isset($_POST['fara_mic_dejun_s']);

// Verificați dacă sunt disponibile valorile necesare
if (!empty($checkin) && !empty($checkout)) {
    // Calculați numărul de zile
    $checkinDate = new DateTime($checkin);
    $checkoutDate = new DateTime($checkout);
    $numarZile = $checkoutDate->diff($checkinDate)->days;

    // Obțineți prețurile pentru Junior Suite din baza de date
    $query = "SELECT pret_mic_dejun, pret_fara_mic_dejun FROM camera WHERE denumire = 'Junior Suite'";
    $result = $conn->query($query);

    $querySenior = "SELECT pret_mic_dejun, pret_fara_mic_dejun FROM camera WHERE denumire = 'Sky Senior Suite'";
    $resultSenior = $conn->query($querySenior);

    if ($result->num_rows > 0 && $resultSenior->num_rows > 0) {
        $row = $result->fetch_assoc();
        $pretMicDejun = $row['pret_mic_dejun'];
        $pretFaraMicDejun = $row['pret_fara_mic_dejun'];

        $rowSenior = $resultSenior->fetch_assoc();
        $pretMicDejunSenior = $rowSenior['pret_mic_dejun'];
        $pretFaraMicDejunSenior = $rowSenior['pret_fara_mic_dejun'];

        // Calculați prețul total în funcție de opțiunile selectate
        $pretTotal = 0;
        $pretTotalSenior = 0;

        if ($micDejun) {
            $pretTotal = $numarZile * $pretMicDejun;
        } elseif ($faraMicDejun) {
            $pretTotal = $numarZile * $pretFaraMicDejun;
        }

        if ($micDejunS) {
            $pretTotalSenior = $numarZile * $pretMicDejunSenior;
        } elseif ($faraMicDejunS) {
            $pretTotalSenior = $numarZile * $pretFaraMicDejunSenior;
        }

        // Construiți un array cu prețurile calculate
        $response = array(
            'pretTotalJunior' => $pretTotal,
            'pretTotalSenior' => $pretTotalSenior
        );
        session_start();
        if (isset($_SESSION['nume']) && isset($_SESSION['prenume'])) {
            $email = $_SESSION['email'];
        }
       

        if ($pretTotal != 0) {
            $tipCamera = "Junior Suite";
            $insertQuery = "INSERT INTO rezervare (email, check_in, check_out, pret, mic_dejun, tip_camera) 
                            VALUES ('$email', '$checkin', '$checkout', $pretTotal, $micDejun, '$tipCamera')";
            if ($conn->query($insertQuery) === TRUE) {
                //echo "Inserarea a fost realizată cu succes!";
            } else {
               // echo "Eroare la inserarea în baza de date: " . $conn->error;
            }
        } 
        
        if ($pretTotalSenior != 0) {
            $tipCamera = "Sky Senior Suite";
            $insertQuery = "INSERT INTO rezervare (email, check_in, check_out, pret, mic_dejun, tip_camera) 
                            VALUES ('$email', '$checkin', '$checkout', $pretTotalSenior, $micDejunS, '$tipCamera')";
            if ($conn->query($insertQuery) === TRUE) {
                //echo "Inserarea a fost realizată cu succes!";
            } else {
               // echo "Eroare la inserarea în baza de date: " . $conn->error;
            }
        }
        

        header('Content-Type: application/json');
        echo json_encode($response);
    } else {
        echo "Nu s-au găsit prețurile pentru Junior Suite.";
    }
} else {
    echo "Vă rugăm să completați data de check-in și check-out.";
}

$conn->close();
?>