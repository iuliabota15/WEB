<?php
// Replace the values inside the brackets with your own database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hotel";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>
<?php
$sql = "SELECT * FROM camera WHERE denumire = 'Camere Family'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $denumire = $row["denumire"];
        $descriere = $row["descriere"];
        $persoane = $row["persoane"];
        $dimensiune = $row["dimensiune"];
        $paturi = $row["paturi"];
        $tv = $row["tv"];
        $internet = $row["internet"];
        $aer_conditionat = $row["aer_conditionat"];
        $cale_imagine = $row["cale_imagine"];
        $minibar = $row["minibar"];
        $articole_toaleta = $row["articole_toaleta"];
        $descriere2 = $row["descriere2"];
        $dus=$row["shower"];
    }
} else {
    echo "0 results";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Proiect Web</title>
    <meta charset="utf-8">
    <link href="camera_dubla.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/00ae1fa8ee.js" crossorigin="anonymous"></script>

</head>
<body>
<script>
  function logout() {
  var xhr = new XMLHttpRequest();
  xhr.open("POST", "logout.php", true);
  xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4 && xhr.status === 200) {
      window.location.href = "login.html";
    }
  };
  xhr.send();
}</script>

  <!---------navar-->
<section class="header">
      <nav>
        <a href="home.html"><img src="img/logo.png"></a>
        <div class="nav-links" id="navLinks">
          <i class="fa fa-times" onclick="hideMenu()"></i>
          <ul>
            <li><a href="rezervare_clienti.php" > REZERVĂ</a></li>
            <li><a href="text.php"  id="login-link-home"> HOME</a></li>
            <li><a href="restaurant.php"  id="rest-link"> RESTAURANT</a></li>
            <li><a href="camere.php"  id="camere-link"> CAMERE</a></li>
            <li><a href="spa.html"  id="spa-link"> BEAUTY & SPA</a></li>
            <li><a href="contact.html"  id="contact-link" > CONTACT</a></li>
            
            <li><a href="login.html"  id="login-link"> LOGIN</a></li>
            
            <li><a href="edit_profile.html"  id="login-link-edit"> EDITARE CONT</a></li>
            <style>
              .logout-form {
                display: inline;
              }
            </style>
            <form id="logout-form" class="logout-form" action="logout.php" method="post">
              <li><a href="#" onclick="logout()">LOGOUT</a></li>
            </form>
            

            </ul>
  
        </div>
        <i class="fa fa-bars" onclick="showMenu()"></i>
      </nav>
  
  
      <div class="slide-right2">
        <div class="slide-right2-heading">
          <h1>CAMERE FAMILY</h1>
        </div>
      </div>
      
</section>
    <!------------course------>

<section class="course">
<?php
$sql = "SELECT imagini_camera.cale 
        FROM imagini_camera 
        JOIN camera ON imagini_camera.denumire_camera = camera.denumire 
        WHERE camera.denumire = 'Camere Family'";

$result = $conn->query($sql);

$imagini = array();
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $imagini[] = $row["cale"];
    }
} else {
    echo "0 results";
}
?>

    <div class="slideshow-container">
    <?php
        foreach ($imagini as $cale) {
  echo '<div class="mySlides fade">';
  echo '<img src="' . $cale . '" style="width:100%">';
  echo '</div>';
}
?>
      
        <!-- Next and previous buttons -->
        <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
        <a class="next" onclick="plusSlides(1)">&#10095;</a>
      </div>
      <br>
      
      <!-- The dots/circles -->
      <div style="text-align:center">
        <span class="dot" onclick="currentSlide(1)"></span>
        <span class="dot" onclick="currentSlide(2)"></span>
        <span class="dot" onclick="currentSlide(3)"></span>
      </div>




</section>



<section class="course">
    <div class="row">
      <div class="slide-right">
        <h1 style="color: #777; font-size: 35px;">Specificații camera</h1>
        <div class="row3">
          <div class="icon-container">
            <i class="fas fa-users" style="color: #777; font-size: 25px;"></i>
            <p><?php echo $persoane; ?></p>
          </div>
          <div class="icon-container">
            <i class="fas fa-compass" style="color: #777; font-size: 25px;"></i>
            <p><?php echo $dimensiune; ?></p>
          </div>
          <div class="icon-container">
            <i class="fas fa-bed" style="color: #777; font-size: 25px;"></i>
            <p><?php echo $paturi; ?></p>
          </div>
        </div>
        <p></p>
         </div>
      
    </div>
  </section>


  <section class="course">
    <div class="row">
      <div class="slide-right">
        <h1 style="color: #777; font-size: 35px;">Facilități</h1>
        <div class="row3">
            <div class="icon-container">
                <i class="fas fa-tv" style="color: #777; font-size: 25px;"></i>
                <p><?php echo $tv; ?></p>
              </div>
              <div class="icon-container">
                <i class="fas fa-wifi" style="color: #777; font-size: 25px;"></i>
                <p><?php echo $internet; ?></p>
            </div>
            <div class="icon-container">
                <i class="fas fa-martini-glass-empty" style="color: #777; font-size: 25px;"></i>
                <p><?php echo $minibar; ?></p>
            </div>
            <div class="icon-container">
                <i class="fas fa-snowflake" style="color: #777; font-size: 25px;"></i>
                <p><?php echo $aer_conditionat; ?></p>
              </div>
              <div class="icon-container">
                <i class="fas fa-shower" style="color: #777; font-size: 25px;"></i>
                <p><?php echo $dus; ?></p>
              </div>
              <div class="icon-container">
                <i class="fas fa-pump-soap" style="color: #777; font-size: 25px;"></i>
                <p><?php echo $articole_toaleta; ?></p>
              </div>


        </div>
        <p></p>
         </div>
      
    </div>
  </section>


  <section class="course">
    <div class="row">
      <div class="slide-right">
        <h1 style="color: #777; font-size: 35px;">Descriere cameră</h1>
        <p><?php echo $descriere; ?></p>
        <p><?php echo $descriere2; ?></p>
    </div>
  </section>




  <section class="course">
    <div class="row">
      <div class="slide-right">
        <h1 style="color: #777; font-size: 35px;">Regulile casei</h1>
        <p></p> 
        <div class="row3">
          <div class="icon-container">
            <p><br><b>Check-in</b><br>

                începând cu ora 16:00
                La check-in, se percepe o garanție de 500 RON, care va fi restituită la plecare.</p>
          </div>
          <div class="icon-container">
            <p><br><b>Check-out</b><br>

                până în ora 12:00
                Tarife late check-out: până în ora 15:00 – 25%, între 15:00-18:00 – 50%, după 18:00 – 100% din tariful de cazare.</p>
          </div>
          <div class="icon-container">
            <p><br><b>Mențiuni</b></br>

                In interiorul hotelului, fumatul nu este permis, exceptand spatiile special amenajate: balcoane (unde se aplica).
                
                Accesul cu animale de companie in interiorul hotelului nu este permis.</p>
          </div>
          
          
        
      
    </div>
  </section>


  <script>
    var navLinks=document.getElementById("navLinks");
    function showMenu(){
      navLinks.style.right="0";
    }
    function hideMenu(){
      navLinks.style.right="-200px";
    }



    let slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
}
  </script>
</body>
</html>