<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $email = $_POST['email'];
  $parola = $_POST['parola'];

  

  // Verificăm dacă parola este corectă
  $conexiune = mysqli_connect("localhost", "root", "", "hotel");
  $query = "SELECT * FROM Utilizator WHERE email = '$email'";
  $rezultat = mysqli_query($conexiune, $query);

  if (mysqli_num_rows($rezultat) == 0) {
    echo "Adresa de email nu există în baza de date.";
  } else {
    $utilizator = mysqli_fetch_assoc($rezultat);
    if ($utilizator['parola'] != $parola) {
      echo "Parola introdusă nu este corectă.";
    } else {
      $query = "DELETE FROM Utilizator WHERE email = '$email'";
      mysqli_query($conexiune, $query);
      echo "Contul a fost șters cu succes.";
    }
  }

  mysqli_close($conexiune);
}
?>
