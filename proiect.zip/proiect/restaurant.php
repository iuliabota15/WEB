<?php
// Replace the values inside the brackets with your own database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hotel";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>Restaurant</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="style.css">
    <link href="restaurant.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap">
<script src="https://kit.fontawesome.com/00ae1fa8ee.js" crossorigin="anonymous"></script>

</head>
<body>
  
<section class="header">
      <nav>
        <a href="text.php"><img src="img/logo.png"></a>
        <div class="nav-links" id="navLinks">
          <i class="fa fa-times" onclick="hideMenu()"></i>
          <ul>
            <li><a href="rezervare_clienti.php" > REZERVĂ</a></li>
            <li><a href="text.php"  id="login-link-home"> HOME</a></li>
            <li><a href="restaurant.php"  id="rest-link"> RESTAURANT</a></li>
            <li><a href="camere.php"  id="camere-link"> CAMERE</a></li>
            <li><a href="spa.html"  id="spa-link"> BEAUTY & SPA</a></li>
            <li><a href="contact.html"  id="contact-link" > CONTACT</a></li>
            
            <li><a href="login.html"  id="login-link"> LOGIN</a></li>
            
            <li><a href="edit_profile.html"  id="login-link-edit"> EDITARE CONT</a></li>
            <style>
              .logout-form {
                display: inline;
              }
            </style>
            <form id="logout-form" class="logout-form" action="logout.php" method="post">
              <li><a href="#" onclick="logout()">LOGOUT</a></li>
            </form>

            </ul>
  
        </div>
        <i class="fa fa-bars" onclick="showMenu()"></i>
      </nav>
  
  
      <div class="slide-right2">
        <div class="slide-right2-heading">
          <h1>RESTAURANT</h1>
        </div>
      </div>
      
</section>
    <!------------course------>

    <section class="course2">
      <div class="row2">
        <div class="slide-right2">
          <h1 style="color: #555; font-size: 35px;">EXCELENȚĂ</h1>
          <p></p>
          <p style="color: #555;">Un amestec încântător de arome și culori în care preparatele fine se împletesc perfect cu ingrediente dăruite de natură, pentru o experiență Fine Dining aparte în centrul orașului Oradea, acompaniată de priveliștea impresionantă a arhitecturii istorice.</p>
           </div>
        <div class="course-col2">
          <h1 style="color: #555; font-size: 35px;">TRADIȚIE</h1>
          <p></p>
          <p style="color: #555;">Și, pentru că suntem în inima orașului Oradea, nu puteam lăsa deoparte tradițiile culinare românești. Pentru un gust autentic și un sentiment de „acasă”, alegeți unul din variatele preparate ale meniului tradițional, în care ingrediente locale și rețete tradiționale se împletesc într-o experiență culinară memorabilă.</p>
           </div>
              
        </div>
        
      </div>
    </section>

    <section class="course2">
      <div class="row2">
        <div class="slide-right2">
         
          <img src="img/restaurantinfo.png"> 
        </div>
        <div class="course-col2">
          <h1 style="color: #555; font-size: 35px;">Filozofia Noastră</h1>
          <p></p>
          <p style="color: #555; font-size: 20px; font-style: italic;"> “Credem că niciun preparat nu poate fi mai bun decât ingredientele sale, de aceea alegem cele mai bune ingrediente de la furnizori diferiți în funcție de sezon. Bucătăria rafinată începe cu ingrediente remarcabile”</p>
           </div>
        </div>
        
      </div>
    </section>





<section class="course">
    <div class="row">
      <div class="slide-right">
        <h1 style="color: #555; font-size: 35px;">FINE DINING</h1>
        <p style="color: #555;">MENIU</p>
      
      </div>
      </div>
 </section>
 <section class="course">
  </section>

  <?php
    // Execute SQL query to retrieve meals with "tip=main courses"
    $sql = "SELECT * FROM feluri_de_mancare WHERE tip='main course'";
    $result = $conn->query($sql);
    ?>


  <div class="row">
    <div class="col">
  <button class="collapsible" style="text-align: center; font-weight: bold;">MAIN COURSES</button>
    
  <div class="content">
    <div class="row">
    <?php
          // Loop through the results of the SQL query
          while($row = $result->fetch_assoc()) {
            // Display the meal's description and price
            echo '<div class="slide-right">';
            echo '<span style="color: #555; font-size: 15px; display: inline-block; width: 50%;">'.$row["denumire"].'</span>';
            echo '<span style="font-size: small ;color: #b17250;; display: inline-block; width: 50%; text-align: right;">'.$row["pret"].' lei</span>';
            
            echo '</div>';
          }
        ?>
    </div></div>
    <?php
    // Execute SQL query to retrieve meals with "tip=main courses"
    $sql = "SELECT * FROM feluri_de_mancare WHERE tip='paste'";
    $result = $conn->query($sql);
    ?>
    <button class="collapsible" style="text-align: center;font-weight: bold;">PASTE</button>
  <div class="content"> <div class="row">
  <?php
          // Loop through the results of the SQL query
          while($row = $result->fetch_assoc()) {
            // Display the meal's description and price
            echo '<div class="slide-right">';
            echo '<span style="color: #555; font-size: 15px; display: inline-block; width: 50%;">'.$row["denumire"].'</span>';
            echo '<span style="font-size: small ;color: #b17250;; display: inline-block; width: 50%; text-align: right;">'.$row["pret"].' lei</span>';
            
            echo '</div>';
          }
        ?>
  </div></div>
  </div>
  <div class="col">

    
  <?php
    // Execute SQL query to retrieve meals with "tip=main courses"
    $sql = "SELECT * FROM feluri_de_mancare WHERE tip='specialitati'";
    $result = $conn->query($sql);
    ?>
  <button class="collapsible" style="text-align: center;font-weight: bold;">SPECIALITĂȚI A LA CHEF</button>
  <div class="content"><div class="row">
  <?php
          // Loop through the results of the SQL query
          while($row = $result->fetch_assoc()) {
            // Display the meal's description and price
            echo '<div class="slide-right">';
            echo '<span style="color: #555; font-size: 15px; display: inline-block; width: 50%;">'.$row["denumire"].'</span>';
            echo '<span style="font-size: small ;color: #b17250;; display: inline-block; width: 50%; text-align: right;">'.$row["pret"].' lei</span>';
            
            echo '</div>';
          }
        ?>
  </div></div>
  <?php
    // Execute SQL query to retrieve meals with "tip=main courses"
    $sql = "SELECT * FROM feluri_de_mancare WHERE tip='desert'";
    $result = $conn->query($sql);
    ?>
  <button class="collapsible" style="text-align: center;font-weight: bold;">DESERT</button>
  <div class="content"><div class="row">
  <?php
          // Loop through the results of the SQL query
          while($row = $result->fetch_assoc()) {
            // Display the meal's description and price
            echo '<div class="slide-right">';
            echo '<span style="color: #555; font-size: 15px; display: inline-block; width: 50%;">'.$row["denumire"].'</span>';
            echo '<span style="font-size: small ;color: #b17250;; display: inline-block; width: 50%; text-align: right;">'.$row["pret"].' lei</span>';
            
            echo '</div>';
          }
        ?>
  </div></div>
</div>

</div>


<section class="course20">
  <img src="img/logo.png"/>
  <div class="row20">
    <div class="course-col20">
      <h3 style="color: #777; font-size: 25px;">Rezervari</h3>
      <p>(+40) 723 534 558   |   (+40) 786 713 722</p>
      <p>rezervari@caelya.com</p>

    </div>

    <div class="course-col20">
      <h3 style="color: #777; font-size: 25px;">Adresa</h3>
      <p>Strada Bumbacului nr.16</p>
      <p>415600 Oradea, Romania</p>

    </div>


  </div>
</section>

<section class="course3">
  <h3 style="color: #838383; font-size: 20px;">Urmărește-ne</h3>
  <div class="row3">
    <a href="https://www.instagram.com/katyperry/" target="_blank"><button class="fa-brands fa-instagram" style="color: #838383;"></button></a>
    <a href="https://www.facebook.com/ellentv/" target="_blank"><button class="fa-brands fa-facebook" style="color: #838383;"></button></a>
    <a href="https://www.youtube.com/channel/UCNL1ZadSjHpjm4q9j2sVtOA" target="_blank"><button class="fa-brands fa-youtube"  style="color: #838383;"></button></a>
  </div>
</section>


<section class="course4" style="color: #777;">
  <p style="color: #222; font-size: small; padding-top: 5px;padding-bottom: 5px; text-align: center;">Copyright ©2008-2020 Hotel Cataleya. Toate drepturile rezervate.</p>
</section>

  
  <script> var navLinks=document.getElementById("navLinks");
    function showMenu(){
      navLinks.style.right="0";
    }
    function hideMenu(){
      navLinks.style.right="-200px";
    }
  </script>

<script>
  var coll = document.getElementsByClassName("collapsible");
  var i;
  
  for (i = 0; i < coll.length; i++) {
    coll[i].addEventListener("click", function() {
      this.classList.toggle("active");
      var content = this.nextElementSibling;
      if (content.style.maxHeight){
        content.style.maxHeight = null;
      } else {
        content.style.maxHeight = content.scrollHeight + "px";
      } 
    });
  }
  </script>
 
 <script>
  function logout() {
  var xhr = new XMLHttpRequest();
  xhr.open("POST", "logout.php", true);
  xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4 && xhr.status === 200) {
      window.location.href = "login.html";
    }
  };
  xhr.send();
}</script>
</body>
</html>