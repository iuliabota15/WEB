<?php
// Pornirea sesiunii
session_start();

// Distrugerea sesiunii
session_destroy();

// Redirecționare către pagina de autentificare
header('Location: text.php');
exit;
?>
