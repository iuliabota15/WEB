<!DOCTYPE html>
<html lang="en">
<head>
    <title>Rezervare</title>
    <meta charset="utf-8">
    <link href="rezervare_clienti.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/00ae1fa8ee.js" crossorigin="anonymous"></script>

</head>
<body>

  <!---------navar-->
<section class="header">
      <nav>
        <a href="text.php"><img src="img/logo.png"></a>
        <div class="nav-links" id="navLinks">
          <i class="fa fa-times" onclick="hideMenu()"></i>
          <ul>
            <li><a href="rezervare_clienti.php" > REZERVĂ</a></li>
            <li><a href="text.php"  id="login-link"> HOME</a></li>
            <li><a href="restaurant.php"  id="rest-link"> RESTAURANT</a></li>
            <li><a href="camere.php"  id="camere-link"> CAMERE</a></li>
            <li><a href="spa.html"  id="spa-link"> BEAUTY & SPA</a></li>
            <li><a href="contact.html"  id="contact-link" > CONTACT</a></li>
            <li><a href="login.html"  id="login-link"> LOGIN</a></li>
            
            <li><a href="edit_profile.html"  id="login-link-edit"> EDITARE CONT</a></li>
            <style>
              .logout-form {
                display: inline;
              }
            </style>
            <form id="logout-form" class="logout-form" action="logout.php" method="post">
              <li><a href="#" onclick="logout()">LOGOUT</a></li>
            </form>
          </ul>
  
        </div>
        <i class="fa fa-bars" onclick="showMenu()"></i>
      </nav>
  
  
      <div class="slide-right2">
        <div class="slide-right2-heading">
          <h1>CAELYA</h1>
        </div>
        <div class="teext">
            <p>Sistemul oficial de rezervare</p>
          </div>
      </div>
  
</section>
<form method="post" id="rezervare-form" action="rezervari_clienti.php">
<section class="course">
  <label for="checkin" style="color: black;">Check-in:</label>
  <input type="date" id="checkin" name="checkin" required> <!-- Adăugat atributul "name" și "required" -->
  <label for="checkout" style="color: black;">Check-out:</label>
  <input type="date" id="checkout" name="checkout" required> <!-- Adăugat atributul "name" și "required" -->
  <br style="color: black;"><br><br><span id="total-price"></span><br>
  <br style="color: black;"><span id="total-price-senior"></span><br>
  
 
</section>
<section class="course">
    <div class="room-type">
        <img src="img/junior-suite-bedroom1.jpg" alt="Junior Suite">
        <div class="room-info">
          <p style="font-size:30px">Junior Suite</p>
          <p>Apartamentele Junior beneficiaza de un decor elegant, spatiu dedicat relaxarii.</p>
          <p>Sunt formate dintr-un living si un dormitor cu pat matrimonial.</p>
          <div class="slide-right2-button">
            <a href="" class="gradient-btn-btn">DETALII</a>
          </div>
          <div class="bottom">
          <div class="left">
            <input type="checkbox" id="mic_dejun" name="mic_dejun">
            <label for="mic_dejun"  style="color: black;">Pret cu Mic Dejun: 250 lei/noapte</label> <!-- Adăugat atributul "for" corespunzător id-ului -->
          </div>
        </div>
          <div class="bottom">
          <div class="left">
            <input type="checkbox" id="fara_mic_dejun" name="fara_mic_dejun">
            <label for="fara_mic_dejun"  style="color: black;">Pret fara Mic Dejun: 190 lei/noapte</label> <!-- Adăugat atributul "for" corespunzător id-ului -->
          </div>
        </div>
        </div>
          <div class="slide-right2-button">
          <input type="submit" name="submit" value="Rezerva acum" data-cameratype="Junior Suite" class="hero-btn"> <!-- Schimbat din <a> în <input type="submit"> -->
        </div>
      </div>
</section><section class="course">
    <div class="room-type">
      <img src="img/sky-senior-suite5.jpg" alt="Senior Suite">
      <div class="room-info">
        <p style="font-size:30px" >Senior Suite</p>
        <p>Apartamentele Senior sunt potrivite pentru calatoriile in cuplu.</p>
        <p>Sunt formate dintr-un living si un dormitor cu pat matrimonial.</p>
        <div class="slide-right2-button">
          <a href="" class="gradient-btn-btn">DETALII</a>
        </div>
        <div class="bottom">
          <div class="left">
            <input type="checkbox" id="mic_dejun_s" name="mic_dejun_s">
            <label for="mic_dejun_s"  style="color: black;">Pret cu Mic Dejun: 400 lei/noapte</label>
          </div>
        </div>
        <div class="bottom">
          <div class="left">
            <input type="checkbox" id="fara_mic_dejun_s" name="fara_mic_dejun_s">
            <label for="fara_mic_dejun_s"  style="color: black;">Pret fara Mic Dejun: 359 lei/noapte</label>
          </div>
        </div>
      </div>
      <div class="slide-right2-button">
        <input type="submit" name="submit_s" value="Rezerva acum" data-cameratype="Sky Senior Suite"class="hero-btn">
      </div>
    </div>
  </section>
</form>



  <section class="course">
  <div class="room-type">
      <img src="img/camera-dubla-cu-balcon1.jpg" alt="Camere duble">
      <div class="room-info">
        <p style="font-size:30px">Camere Duble</p>
        <p>Veti beneficia de o sedere relaxanta si servicii turistice de calitate.</p>
        <p>Camerele duble ale Hotelului Caelya va ofera tot confortul necesar.</p>
        <div class="slide-right2-button">
        <a href="" class="gradient-btn-btn">DETALII</a>
        </div>
        <div class="bottom">
          <div class="left">
            <input type="checkbox" id="mic_dejun_d" name="mic_dejun_d">
            <label for="mic_dejun_d"  style="color: black;">Mic Dejun</label>
          </div>
        </div>
        <div class="bottom">
          <div class="left">
            <input type="checkbox" id="fara_mic_dejun_d" name="fara_mic_dejun_d">
            <label for="fara_mic_dejun_d"  style="color: black;">Fara Mic Dejun</label>
          </div>
        </div>
      </div>
      <div class="slide-right2-button">
        <input type="submit" name="submit_d" value="Rezerva acum" data-cameratype="Camera Dubla"class="hero-btn">
      </div>
    </div>
</section>

<section class="course">
  <div class="room-type">
      <img src="img/camere-family6.jpg" alt="Camere Family">
      <div class="room-info">
        <p style="font-size:30px">Camere Family</p>
        <p>Pentru ca ne dorim sa va oferim o experienta de neuitat.</p>
        <p>Camerele Family sunt formate din doua camere duble alaturate, intercomunicante.</p>
        <div class="slide-right2-button">
        <a href="" class="gradient-btn-btn">DETALII</a>
        </div>
        <div class="bottom">
          <div class="left">
            <input type="checkbox" id="mic_dejun_f" name="mic_dejun_f">
            <label for="mic_dejun_f"  style="color: black;">Mic Dejun</label>
          </div>
        </div>
        <div class="bottom">
          <div class="left">
            <input type="checkbox" id="fara_mic_dejun_f" name="fara_mic_dejun_f">
            <label for="fara_mic_dejun_f"  style="color: black;">Fara Mic Dejun</label>
          </div>
        </div>
      </div>
      <div class="slide-right2-button">
        <input type="submit" name="submit_f" value="Rezerva acum" data-cameratype="Sky Senior Suite"class="hero-btn">
      </div>
    </div>
</section>


  <script>
    var navLinks=document.getElementById("navLinks");
    function showMenu(){
      navLinks.style.right="0";
    }
    function hideMenu(){
      navLinks.style.right="-200px";
    }
  </script>
  
<script>
document.addEventListener('DOMContentLoaded', function() {
  var form = document.getElementById('rezervare-form');
  form.addEventListener('submit', function(event) {
    event.preventDefault(); // Evităm trimiterea formularului în modul implicit

    var xhr = new XMLHttpRequest();
    xhr.open(form.method, form.action, true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function() {
      if (xhr.readyState === 4 && xhr.status === 200) {
        // Actualizăm totalul cu răspunsul primit de la server
        var response = JSON.parse(xhr.responseText);
        var totalPriceElement = document.getElementById('total-price');
        var totalPriceElementSenior = document.getElementById('total-price-senior');

        if (response.pretTotalJunior === 0) {
            totalPriceElement.style.display = 'none';
          } else {
            totalPriceElement.style.display = 'inline';
            totalPriceElement.innerHTML = "Total de plata : "+response.pretTotalJunior + " lei";
          }

          if (response.pretTotalSenior === 0) {
            totalPriceElementSenior.style.display = 'none';
          } else {
            totalPriceElementSenior.style.display = 'inline';
            totalPriceElementSenior.innerHTML = "Total de plata : "+response.pretTotalSenior + " lei";
          }
      }
    };

    // Obținem datele din formular
    var formData = new FormData(form);

    // Trimitem cererea AJAX către rezervari_clienti.php
    xhr.send(new URLSearchParams(formData));
  });
});
</script>
<script>
  function logout() {
  var xhr = new XMLHttpRequest();
  xhr.open("POST", "logout.php", true);
  xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4 && xhr.status === 200) {
      window.location.href = "login.html";
    }
  };
  xhr.send();
}</script>

</body>
</html>