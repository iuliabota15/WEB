<?php
// Verificăm dacă formularul a fost trimis
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  // preluăm datele din formular
  $email = $_POST['email'];
  $parola_veche = $_POST['parola'];
  $parola_noua = $_POST['parola_noua'];
  $confirmare = $_POST['confirmare'];
  
  // Verificăm dacă emailul există în baza de date
  $conexiune = mysqli_connect("localhost", "root", "", "hotel");
  $query = "SELECT * FROM Utilizator WHERE email = '$email'";
  $rezultat = mysqli_query($conexiune, $query);
  
  if (mysqli_num_rows($rezultat) == 0) {
    echo "Adresa de email nu există în baza de date.";
  } else {
    // Verificăm dacă parola veche este corectă
    $utilizator = mysqli_fetch_assoc($rezultat);
    if ($utilizator['parola'] != $parola_veche) {
      echo "Parola veche introdusă nu este corectă.";
    } else {
      // Verificăm dacă parola nouă și confirmarea sunt identice
      if ($parola_noua != $confirmare) {
        echo "Parola nouă și confirmarea trebuie să fie identice.";
      } else {
        // Actualizăm parola în baza de date
        $query = "UPDATE Utilizator SET parola = '$parola_noua' WHERE email = '$email'";
        mysqli_query($conexiune, $query);
        echo "Parola a fost actualizată cu succes.";
      }
    }
  }
  mysqli_close($conexiune);
}
?> 