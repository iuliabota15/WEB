<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "hotel";

$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die("Conexiunea la baza de date a esuat: " . mysqli_connect_error());
}

$nume = $_POST['nume'];
$prenume = $_POST['prenume'];
$email = $_POST['email'];
$parola = $_POST['parola'];
$confirmare = $_POST['confirmare'];
$termeni = $_POST['termeni'];

$email_exist = mysqli_query($conn, "SELECT * FROM Utilizator WHERE email = '$email'");

if(mysqli_num_rows($email_exist) > 0){
    echo "Eroare: Adresa de email este deja inregistrata.";
} else {
    if(!isset($termeni)){
        echo "Eroare: Trebuie să fiți de acord cu termenii și condițiile.";
    } else {
        if ($parola == $confirmare) {
            $sql = "INSERT INTO Utilizator (nume, prenume, email, parola) VALUES ('$nume', '$prenume', '$email', '$parola')";

            if (mysqli_query($conn, $sql)) {
                header("Location: text.php");
                exit();
            } else {
                echo "Eroare: " . mysqli_error($conn);
            }
        } else {
            echo "Eroare: Parola și confirmarea parolei nu corespund.";
        }
    }
}

mysqli_close($conn);
?>
